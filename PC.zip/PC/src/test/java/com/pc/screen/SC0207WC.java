package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

public class SC0207WC {

	public static String sheetname = "SC0207WC";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	
	public Boolean SCRSC0207WC() throws Exception{

		Boolean status = true;
		status = common.ClassComponent(sheetname, Common.o);
		if(!status)
		{
			return false;
		}
		if(common.WaitUntilClickable(Common.o.getObject("eleAccountFileSummary"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed AccountFileSummary Page");  
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AccountFileSummary Page","System displayed AccountFileSummary Page", "PASS");
			status = true;
		}
		else
		{
			logger.info("System not displayed AccountFileSummary Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AccountFileSummary Page","System not displayed AccountFileSummary Page", "FAIL");
			status = false;
		}
	return status;
	}
	public boolean VerifyRenewalStatus(String funValue) throws Exception
	{
		boolean status = false;
		logger.info("Verify the Results");
		String[] sValue = funValue.split(":::");
		String Value = null;
			switch (sValue[0].toUpperCase())
			{				
				
				case "POLICYINFOSPECTRUM":
					logger.info(sValue[0]);
					Value = common.ReadElement(Common.o.getObject("elePolicyInfoSpectrum"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));

			}
			return status;
	}
}
