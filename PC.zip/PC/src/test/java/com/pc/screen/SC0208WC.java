package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

public class SC0208WC {

	public static String sheetname = "SC0208WC";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	
	public Boolean SCRSC0208WC() throws Exception{

		Boolean status = true;
		status = common.ClassComponent(sheetname, Common.o);
		if(!status)
		{
			return false;
		}
		if(common.WaitUntilClickable(Common.o.getObject("elePolicyInfo"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed PolicyInfo  Page");  
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display PolicyInfo Page","System displayed PolicyInfo Page", "PASS");
			status = true;
		}
		else
		{
			logger.info("System not displayed PolicyInfo Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display PolicyInfo Page","System not displayed PolicyInfo Page", "FAIL");
			status = false;
		}
	return status;
	}
}

