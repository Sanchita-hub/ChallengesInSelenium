package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

public class SC0205 {

	public static String sheetname = "SC0205";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	
    

public Boolean SCRSC0205() throws Exception{
	
	Boolean status = true;
	status = common.ClassComponent(sheetname, Common.o);
	if(!status)
	{
		return false;
	}
	if(common.WaitUntilClickable(Common.o.getObject("eleAutoSummary"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
	{
		logger.info("System displayed AutoSummary page");
		HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AutoSummary page","System displayed AutoSummary page", "PASS");
		status = true;
	}
	else
	{
		logger.info("System not displayed AutoSummary page");
		HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AutoSummary page","System not displayed AutoSummary page", "FAIL");
		status = false;
	}
		return status;
}
}