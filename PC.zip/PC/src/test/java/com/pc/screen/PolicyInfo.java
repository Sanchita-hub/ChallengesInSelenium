package com.pc.screen;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class PolicyInfo {
	
		public static String sheetname = "PolicyInfo";
		static Logger logger =Logger.getLogger(sheetname);
		Common common = CommonManager.getInstance().getCommon();
		//459083
		private WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		public Boolean SCRPolicyInfo() throws Exception{
						Boolean status = true;
			status = common.ClassComponent(sheetname, Common.o);
			if(!status)
			{
				status = false;
			}
			return status;
	}
		
		public boolean VerifyResults(String sFuncValue) throws Exception
		{
			boolean status = false;
			String[] sValue = sFuncValue.split(":::");
			logger.info("Verifying the Results");
			String Value = null;
				switch (sValue[0].toUpperCase())
				{				
						case "VERIFYPOLICYINFO":
					    logger.info(sValue[0]);
						Value = common.ReadElementGetAttribute(Common.o.getObject("edtIndusCode"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[1], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("edtNAICS"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[2], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("edtMSI"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[3], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("edtEBS"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[4], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("lstOrganisationType"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[5], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("edtFEIN"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[6], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("lstProductType"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[7], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("lstSubmissionSource"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[8], Value);
						Value = common.ReadElementGetAttribute(Common.o.getObject("lstSalesAgreementCode"), "value", Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));
						status = common.CompareStringResult(sValue[0], sValue[9], Value);
						break;
						case "VERIFYPOLICYINFOSCREEN":
							Value = common.ReadElement(Common.o.getObject("elePolicyInfoAssert"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
							status = common.CompareStringResult(sValue[0], sValue[1], Value);
							break;
						case "VERIFYBORSTARTDATE":
			                    logger.info(sValue[0]);
			                                  
			                                  Value = common.ReadElement(Common.o.getObject("elePolBORStartDate"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                                  status = common.CompareStringResult("PolicyBORStartDate", SCRCommon.ReturnCurrentDate(), Value);
			                               break;
			                               
			                           case "VERIFYBORENDDATE":
			                                  logger.info(sValue[0]);
			                                  Value = common.ReadElementGetAttribute(Common.o.getObject("elePolBOREndDate"),"value", Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                                status = common.CompareStringResult("PolicyBOREnd", sValue[1], Value);
			                                break;
			                                
			                           case "BORDATE":
			                                  logger.info(sValue[0]);
			                                  
			                                  Value = common.ReadElement(Common.o.getObject("elePolBORStartDate"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                                  status = common.CompareStringResult("PolicyBORStartDate", SCRCommon.ReturnCurrentDate(), Value);
			                                  Value = common.ReadElement(Common.o.getObject("elePolBOREndDate"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                                  status = common.CompareStringResult("PolicyBOREndDate", SCRCommon.ReturnSixtyDaysFromDate(), Value);
			                                  break;
			                           case "VERIFYSORBORNOTSET":
			                               logger.info(sValue[0]);
			                               Value = common.ReadElement(Common.o.getObject("elePolBORStartDate"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                               if(Value.equals(SCRCommon.ReturnCurrentDate()))
			                               {
			                                      status = false;
			                                      HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Current Date should not match","Current Date is matching", "FAIL");
			                               }else{
			                                      status = true;
			                                      HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Current Date should not match","Current Date is not matching", "PASS");
			                               }
			                               
			                               Value = common.ReadElement(Common.o.getObject("elePolBOREndDate"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")));
			                               if(Value.equals(SCRCommon.ReturnSixtyDaysFromDate()))
			                               {
			                                      status = false;
			                                      HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Sixty Days from Current Date should not match","Sixty Days from Current Date is matching", "FAIL");
			                               }else{
			                                      status = true;
			                                      HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Sixty Days from Current Date should not match","Sixty Days from Current Date is not matching", "PASS");
			                               }
			                               
			                                break; 
		      	}
				if(!status)
				{
					HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), ""+sValue[0]+" case should PASS",""+sValue[0]+" case should not fail", "FAIL");
					status = true;
				}
			return status;
		}
		
		public boolean SelectDropDownValue() throws Exception 
		{
			boolean status = false;
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleSelectBillingNum")).click();
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleSelectBillingNum")).sendKeys(Keys.ARROW_DOWN);
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleSelectBillingNum")).sendKeys(Keys.ENTER);
				common.WaitForPageToBeReady();
			status=true;
			return status;
		} 
		
}
