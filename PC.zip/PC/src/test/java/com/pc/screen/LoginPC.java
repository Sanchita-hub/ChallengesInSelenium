package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

public class LoginPC {
	public static String sheetname = "LoginPC";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	
	public Boolean SCRLoginPC() throws Exception
	{
		
		Boolean s = common.OpenApp();
		if(!s)
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "PASS");
			return false;
		}
		Boolean status = true;
		status = common.ClassComponent(sheetname,Common.o);
		if(!status)
		{
			return status;
		}
		if(common.WaitUntilClickable(Common.o.getObject("eleDeskTopAction"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("Application Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application loggedin successfully", "PASS");
			status = true;
		}
		else
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "FAIL");
			status = false;
		}
	
			return status;
	}
}
