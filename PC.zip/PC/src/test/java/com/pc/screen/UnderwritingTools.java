package com.pc.screen;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.ManagerDriver;

public class UnderwritingTools {

	public static String sheetname = "UnderwritingTools";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	private WebDriver driver = ManagerDriver.getInstance().getWebDriver();

	public Boolean SCRUnderwritingTools() throws Exception
	{
		Boolean status = true;
		status = common.ClassComponent(sheetname,Common.o);
		if(!status)
		{
			status = false;
		}
		return status;
	}
	public boolean SelectTransactionOnBasisOfProduct(){

		boolean status = false;
		try{
			if(ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleFirstPolicyInTransTable")).isDisplayed()){
				for(int i=1;i<=15;i++)
				{
					if(driver.findElement(By.xpath("//div[@id='AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_WorkOrdersLV-body']/div/table/tbody/tr["+i+"]/td[6]/div")).getText().equals("Commercial Multi Peril")){
						{	 driver.findElement(By.xpath("//div[@id='AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_WorkOrdersLV-body']/div/table/tbody/tr["+i+"]/td[2]/div/a")).click();
						status=true;
						break;
						}
					}
				}
			}
		}
		
		catch(Exception e){}
		return status;

	}
}