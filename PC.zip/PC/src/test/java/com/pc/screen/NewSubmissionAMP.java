
package com.pc.screen;

//import java.text.SimpleDateFormat;
//import java.util.Calendar;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;
//import com.pc.utilities.HTML;
//import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class NewSubmissionAMP {
	
	public static String sheetname = "NewSubmissionAMP";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	public static XlsxReader sXL;
	
	public Boolean SCRNewSubmissionAMP() throws Exception
	{		
		Boolean status = true;
		status = common.ClassComponent(sheetname, Common.o);
		if(!status)
		{
			return false;
		}
		return status;
	}
   
	public boolean DefaultEffectiveDate() throws Exception
	{
		boolean status = false;
		String sCurrentDate = SCRCommon.ReturnCurrentDate();
		status = common.SafeAction(Common.o.getObject("edtEffDate"), sCurrentDate, "edt");
		return status;
	}
	public boolean SelectLOB(String value) throws Exception 
	{
		boolean status = false;
		String[] sValue = value.split(":::");
		try
		{
			status = common.ActionOnTable(Common.o.getObject("funSelectLOBAMP"), 1,0,sValue[0],sValue[1], "a");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	public boolean SelectMultipleLOB(String value) throws Exception 
	{
		boolean status = false;
		String[] sValue = value.split(":::");
		try
		{
			status = common.ActionOnTableSelect(Common.o.getObject("eleProductNameTable"),2,0,sValue[0],sValue[1],sValue[2], "div");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	public boolean VerifyResults(String sFuncValue) throws Exception
	{
		boolean status = false;
		String[] sValue = sFuncValue.split(":::");
		logger.info("Verifying the Results");
		String Value = null;
			switch (sValue[0].toUpperCase())
			{				
					case "VERIFYNONAMPLOB":
				    logger.info(sValue[0]);
				  	Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[1]);
					status = common.CompareStringResult(sValue[0], sValue[1], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[2]);
					status = common.CompareStringResult(sValue[0], sValue[2], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[3]);
					status = common.CompareStringResult(sValue[0], sValue[3], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[4]);
					status = common.CompareStringResult(sValue[0], sValue[4], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[5]);
					status = common.CompareStringResult(sValue[0], sValue[5], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[6]);
					status = common.CompareStringResult(sValue[0], sValue[6], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[7]);
					status = common.CompareStringResult(sValue[0], sValue[7], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[8]);
					status = common.CompareStringResult(sValue[0], sValue[8], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[9]);
					status = common.CompareStringResult(sValue[0], sValue[9], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[10]);
					status = common.CompareStringResult(sValue[0], sValue[10], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[11]);
					status = common.CompareStringResult(sValue[0], sValue[11], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[12]);
					status = common.CompareStringResult(sValue[0], sValue[12], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[13]);
					status = common.CompareStringResult(sValue[0], sValue[13], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[14]);
					status = common.CompareStringResult(sValue[0], sValue[14], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[15]);
					status = common.CompareStringResult(sValue[0], sValue[15], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[16]);
					status = common.CompareStringResult(sValue[0], sValue[16], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[17]);
					status = common.CompareStringResult(sValue[0], sValue[17], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[18]);
					status = common.CompareStringResult(sValue[0], sValue[18], Value);
					Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[19]);
					status = common.CompareStringResult(sValue[0], sValue[19], Value);
					break;
					case "VERIFYAMPLOB":
						 logger.info(sValue[0]);
						  	Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[1]);
							status = common.CompareStringResult(sValue[0], sValue[1], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[2]);
							status = common.CompareStringResult(sValue[0], sValue[2], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[3]);
							status = common.CompareStringResult(sValue[0], sValue[3], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[4]);
							status = common.CompareStringResult(sValue[0], sValue[4], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[5]);
							status = common.CompareStringResult(sValue[0], sValue[5], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[6]);
							status = common.CompareStringResult(sValue[0], sValue[6], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[7]);
							status = common.CompareStringResult(sValue[0], sValue[7], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[8]);
							status = common.CompareStringResult(sValue[0], sValue[8], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[9]);
							status = common.CompareStringResult(sValue[0], sValue[9], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[10]);
							status = common.CompareStringResult(sValue[0], sValue[10], Value);
							Value = common.GetTextFromTable(Common.o.getObject("eleProductNameTable"), 1, sValue[11]);
							status = common.CompareStringResult(sValue[0], sValue[11], Value);
							break;
						
	      	}
			if(!status)
			{
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), ""+sValue[0]+" case should PASS",""+sValue[0]+" case should not fail", "FAIL");
				status = true;
			}
		return status;
	}
	//459083
	public boolean EnterCurrentDate() throws Exception
	{
		boolean status = false;
		String sCurrentDate = SCRCommon.ReturnCurrentDateTime();
		status = common.SafeAction(Common.o.getObject("edtSubOriginalReceivedDt"), sCurrentDate, "edt");
		return status;
	}
	public boolean EnterNBCurrentDate() throws Exception
	{
		boolean status = false;
		String sCurrentDate = SCRCommon.ReturnCurrentDateTime();
		status = common.SafeAction(Common.o.getObject("edtNBReceivedDt"), sCurrentDate, "edt");
		return status;
	}
	
	  
}
