package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

public class AccountNameSelect {
	
	public static String sheetname = "AccountNameSelect";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);

public Boolean SCRAccountNameSelect() throws Exception{
	
	Boolean status = true;
	status = common.ClassComponent(sheetname, Common.o);
	if(!status)
	{
		return false;
	}
	if(common.WaitUntilClickable(Common.o.getObject("eleAccountInformation"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
	{
		logger.info("System displayed AccountInformation page");
		HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AccountInformation page","System displayed AccountInformation page", "PASS");
		status = true;
	}
	else
	{
		logger.info("System not displayed AccountInformation page");
		HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display AccountInformation page","System not displayed AccountInformation page", "FAIL");
		status = false;
	}
		return status;
}

}
